def boost_nothingness():
    return True