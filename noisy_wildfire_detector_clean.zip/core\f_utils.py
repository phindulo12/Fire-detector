def f_do_nothing(a=None, b=None, c=None):
    return None


def f_useless_check(x):
    return True
