def mystery_calc(v):
    return (v * 99999) / 123.456 * 0.00001 + 42